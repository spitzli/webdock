import * as react_jsx_runtime from 'react/jsx-runtime';
import { Node, Edge } from '@xyflow/react';

interface TableQueryTemplateRequest {
    table: string;
    schema: string | null;
    kind: "select" | "update" | "delete";
    columns: string[];
    limit: number | null;
}

interface DataTypeInfo {
    name: string;
    category: string;
    requires_length: boolean;
    requires_precision: boolean;
    default_length?: string;
    supports_auto_increment: boolean;
    requires_extension?: string;
}
interface DataTypeRegistry {
    driver: string;
    types: DataTypeInfo[];
}

/** Shared proxy configuration types (mirrors Rust `proxy::types`). */
type ProxyProtocol = "http" | "socks5";
type ProxyMode = "inherit" | "custom" | "disabled";
type ProxyScopeId = "app_http" | "database" | "ai" | "ssh_tunnel";
interface ProxyEndpoint {
    protocol: ProxyProtocol;
    host: string;
    port: number;
    username?: string;
}
interface ProxyOverride {
    mode: ProxyMode;
    endpoint?: ProxyEndpoint;
}
interface GlobalProxySettings {
    enabled: boolean;
    endpoint?: ProxyEndpoint;
    /** Missing key ⇒ false (opt-in per scope). */
    scopes: Partial<Record<ProxyScopeId, boolean>>;
}

type Dialect = 'postgres' | 'mysql' | 'mssql' | 'sqlite' | 'oracle' | 'generic';

interface ConnectionStringExample {
    label: string;
    value: string;
    description?: string;
}
interface DriverCapabilities {
    schemas: boolean;
    views: boolean;
    routines: boolean;
    file_based: boolean;
    folder_based: boolean;
    /** The driver exposes a single implicit database (e.g. a flat search/document
     * store like Meilisearch). Skips the database tab + database-name field. */
    single_database?: boolean;
    /** Optional flag to enable/disable connection string import UI for network drivers. Defaults to true when omitted. */
    connection_string?: boolean;
    /** CamelCase alias accepted for plugin compatibility. */
    connectionString?: boolean;
    /** Optional placeholder example shown in the connection string input. */
    connection_string_example?: string;
    /** Optional presets shown beside the connection string field. */
    connection_string_examples?: ConnectionStringExample[];
    /** CamelCase alias accepted for plugin compatibility. */
    connectionStringExample?: string;
    /** CamelCase alias accepted for plugin compatibility. */
    connectionStringExamples?: ConnectionStringExample[];
    /** The driver consumes the raw connection URI verbatim instead of the decomposed
     * host/port/database fields. Set by drivers whose scheme carries semantics the
     * decomposition would destroy (e.g. the DNS seedlist lookup implied by
     * `mongodb+srv://`). Defaults to false. */
    connection_uri?: boolean;
    /** CamelCase alias accepted for plugin compatibility. */
    connectionUri?: boolean;
    /** Additional URI schemes handled by this driver, beyond its own id and the scheme
     * of `connection_string_example` (e.g. ["mongodb+srv"]). */
    connection_uri_schemes?: string[];
    /** CamelCase alias accepted for plugin compatibility. */
    connectionUriSchemes?: string[];
    identifier_quote: string;
    alter_primary_key: boolean;
    auto_increment_keyword?: string;
    serial_type?: string;
    inline_pk?: boolean;
    /** Opts Generate SQL into the optional get_table_query_template RPC. Defaults to false. */
    table_query_templates?: boolean;
    alter_column?: boolean;
    create_foreign_keys?: boolean;
    /** true for API-based plugins that need no host/port/credentials (e.g. public REST APIs). Hides the entire connection form. */
    no_connection_required?: boolean;
    /** Whether the driver supports table and column management (CREATE TABLE, ADD/MODIFY/DROP COLUMN, DROP TABLE). Does not control index or FK operations. Defaults to true. */
    manage_tables?: boolean;
    /** When true, the driver is read-only: all data modification operations (INSERT, UPDATE, DELETE) are disabled in the UI. Table/column management is also hidden regardless of manage_tables. Defaults to false. */
    readonly?: boolean;
    /** Supports EXPLAIN / query plan visualization. When false, the Visual Explain UI is hidden for connections using this driver. Defaults to false. */
    explain?: boolean;
    /** Supports listing and managing database triggers. Defaults to false. */
    triggers?: boolean;
    /** Supports listing and managing server accounts (users, grants). Defaults to false. */
    user_management?: boolean;
    /** Supports managing stored routines (run with parameters, create from template, edit, drop). Defaults to false. */
    routine_management?: boolean;
    /** Supports materialized views (e.g. PostgreSQL). When false, the frontend skips fetching materialized views entirely. Defaults to false. */
    materialized_views?: boolean;
    /** Shows the SSL/TLS configuration tab (mode + CA/client cert/key) in the connection modal.
     * Built-in network drivers (postgres, mysql) set this; plugins opt in via their manifest. Defaults to false. */
    supports_ssl?: boolean;
    /**
     * SQL dialect for the statement splitter / classifier. Plugins that
     * omit the field fall back to "postgres" (the dialect everyone got
     * implicitly via the previous splitter).
     */
    sql_dialect?: Dialect;
}
/** Non-fatal plugin warning queued by the host, e.g. a runtime version mismatch. */
interface PluginRuntimeWarning {
    plugin_id: string;
    message: string;
}
/** Effective metadata for one connection. The registered manifest stays static. */
interface ConnectionMetadata {
    capabilities: DriverCapabilities;
    data_types: DataTypeInfo[];
    type_mappings: Record<string, string>;
}
type PluginSettingType = "string" | "boolean" | "number" | "select";
interface PluginSettingDefinition {
    key: string;
    label: string;
    type: PluginSettingType;
    default?: string | boolean | number;
    description?: string;
    required?: boolean;
    options?: string[];
}
/** Deprecation notice for a built-in driver being retired in favour of a
 * standalone plugin. Absent on manifests for drivers that are not deprecated.
 * Stamped onto built-in manifests by the backend at registration time. */
interface DeprecationInfo {
    /** Driver id of the replacement plugin (e.g. "postgresql"). */
    replacement_id?: string;
    /** Human-readable target removal date (tentative, e.g. "2026-10-05"). */
    removal_date?: string;
    /** App version targeted for removal, if decided. */
    removal_version?: string;
}
interface PluginManifest {
    id: string;
    name: string;
    version: string;
    description: string;
    default_port: number | null;
    capabilities: DriverCapabilities;
    /** Present on get_driver_manifest when the plugin opts in to discovery. */
    connection_metadata?: boolean;
    /** true for built-in drivers (postgres, mysql, sqlite); false/absent for external plugins */
    is_builtin?: boolean;
    /** Concrete database engine (registry manifest `engine`). Lets the connection
     * catalogue place locally-installed, not-yet-published plugins. */
    engine?: string | null;
    /** Data-model families, primary first (registry manifest `paradigms`). */
    paradigms?: string[];
    /** Default username pre-filled in the connection modal (e.g. "postgres", "root") */
    default_username?: string;
    /** CSS hex color for UI accents (e.g. "#f97316"). Undefined falls back to a neutral color. */
    color?: string;
    /** Icon: a hosted URL (`https://...`) or `data:` URI, resolved to an
     * `<img>` (see the Tabularium manifest docs); or one of the built-in
     * lookup keys "mysql" | "postgres" | "sqlite" | "network" | "database" |
     * "folder-open", resolved to an inline brand/lucide icon. */
    icon?: string;
    /** Plugin-declared setting definitions. Empty/absent for built-in drivers. */
    settings?: PluginSettingDefinition[];
    /** Optional map of generic inferred type names to driver-specific types.
     * Used during paste/import to resolve map_inferred_type() locally. */
    type_mappings?: Record<string, string>;
    /** UI extension declarations for slot-based rendering (Phase 2). */
    ui_extensions?: UIExtensionManifestEntry[];
    /** Deprecation notice for a built-in driver being retired in favour of a
     * plugin. Absent/undefined for non-deprecated drivers. */
    deprecated?: DeprecationInfo;
    /** Raw EXPLAIN parser bundles loaded when this plugin is enabled. */
    explain_parsers?: ExplainParserManifestEntry[];
}
/** Manifest-level declaration for a plugin-owned EXPLAIN parser bundle. */
interface ExplainParserManifestEntry {
    engine: string;
    format: string;
    module: string;
    label?: string;
}
/** Manifest-level entry for a UI extension slot. */
interface UIExtensionManifestEntry {
    slot: string;
    module: string;
    order?: number;
    /** If set, the contribution is only active when context.driver matches this value. */
    driver?: string;
    /** @tabularis/plugin-api version used to build this bundle. */
    api_version?: string;
}
/**
 * Locale-aware README payload from the `fetch_plugin_readme` command.
 * `html` is the registry's server-rendered README; `locale` is the locale
 * actually served, which can differ from the requested one when the plugin
 * has no translation for it.
 */
interface PluginReadme {
    html: string | null;
    locale: string | null;
    available_locales?: string[];
    documentation_url?: string | null;
    /** Repository URL, used to resolve relative image/link paths in the README. */
    repo_url?: string | null;
}
interface RegistryReleaseWithStatus {
    version: string;
    min_tabularis_version: string | null;
    platform_supported: boolean;
}
interface RegistryPluginWithStatus {
    id: string;
    name: string;
    description: string;
    author: string;
    homepage: string;
    latest_version: string;
    releases: RegistryReleaseWithStatus[];
    installed_version: string | null;
    update_available: boolean;
    platform_supported: boolean;
    icon?: string | null;
    repo_url?: string | null;
    kind?: string | null;
    tags?: string[];
    category?: string | null;
    downloads?: number | null;
    /** Base URL of the registry that served this plugin (e.g. https://registry.tabularis.dev). */
    registry_base_url?: string | null;
    /** Concrete database the driver connects to (registry manifest extensions.engine). */
    engine?: string | null;
    /** Data-model families, primary first (registry manifest extensions.paradigms). */
    paradigms?: string[];
    /** Registry-assigned verification flag. */
    verified?: boolean;
    /** Deeplink-only: resolved action for the confirmation modal. */
    install_action?: "install" | "update" | "up_to_date" | null;
    /**
     * Release-integrity signature state for the target version (preview path).
     * Distinct from `verified` (admin moderation) — this is the cryptographic
     * signature over the release's asset hashes.
     */
    signature?: "verified" | "unsigned" | "invalid" | "unknown" | null;
}
interface InstalledPluginInfo {
    id: string;
    name: string;
    version: string;
    description: string;
}
interface PluginLoadError {
    plugin_id: string;
    error: string;
}

interface TableInfo {
    name: string;
    schema?: string;
    comment?: string | null;
}
interface ViewInfo {
    name: string;
    definition?: string;
}
interface RoutineInfo {
    name: string;
    routine_type: string;
    definition?: string;
}
interface TriggerInfo {
    name: string;
    table_name: string;
    event: string;
    timing: string;
    definition?: string;
}
type IconOverride = {
    type: "pack";
    id: string;
} | {
    type: "emoji";
    value: string;
} | {
    type: "image";
    path: string;
};
interface ConnectionAppearance {
    icon?: IconOverride;
    accentColor?: string;
}
interface SavedConnection {
    id: string;
    name: string;
    params: {
        driver: string;
        host?: string;
        database: string | string[];
        port?: number;
        username?: string;
        password?: string;
        ssh_enabled?: boolean;
        ssh_connection_id?: string;
        k8s_enabled?: boolean;
        k8s_connection_id?: string;
        ssm_enabled?: boolean;
        ssm_target?: string;
        startup_script?: string;
        /** SSL/TLS mode (e.g. "verify-ca"); empty/absent means SSL is off. Used
         * by findUnsupportedFeatures to detect a plugin capability gap. */
        ssl_mode?: string;
        /** Raw driver-specific connection URI, when present at runtime (never
         * persisted to disk — see connection_uri_in_keychain below). */
        connection_uri?: string;
        /** True when a connection URI is restorable from the OS keychain. A
         * driver flip drops it (by design — a stored URI belongs to the driver
         * that produced it), so the migration confirm warns before this happens. */
        connection_uri_in_keychain?: boolean;
        /** Optional proxy override for this connection. */
        proxy?: ProxyOverride;
    };
    group_id?: string;
    sort_order?: number;
    /** Per-connection opt-in: detect JSON in plain text columns. */
    detect_json_in_text_columns?: boolean;
    appearance?: ConnectionAppearance;
    /** Ids of connection tags attached to this connection. */
    tag_ids?: string[];
    /** Deployment environment; production drives warnings and visuals. */
    environment?: "development" | "staging" | "production";
}
interface ConnectionGroup {
    id: string;
    name: string;
    collapsed: boolean;
    sort_order: number;
    /** When set, this group is a child of another group. `undefined` or `null`
     * means top-level root. Cycles are rejected by the backend. */
    parent_id?: string | null;
}
interface ConnectionsFile {
    groups: ConnectionGroup[];
    connections: SavedConnection[];
}

/** A user-defined colored label assignable to any number of connections. */
interface ConnectionTag {
    id: string;
    name: string;
    /** CSS hex color, e.g. "#f97316". */
    color: string;
}

interface ExplainNode {
    id: string;
    node_type: string;
    relation: string | null;
    startup_cost: number | null;
    total_cost: number | null;
    plan_rows: number | null;
    actual_rows: number | null;
    actual_time_ms: number | null;
    actual_loops: number | null;
    buffers_hit: number | null;
    buffers_read: number | null;
    filter: string | null;
    index_condition: string | null;
    join_type: string | null;
    hash_condition: string | null;
    extra: Record<string, unknown>;
    children: ExplainNode[];
}
interface ExplainPlan {
    root: ExplainNode;
    planning_time_ms: number | null;
    execution_time_ms: number | null;
    original_query: string;
    driver: string;
    has_analyze_data: boolean;
    raw_output: string | null;
}

/**
 * The boundary between a host driver and the parsers.
 *
 * A built-in driver runs `EXPLAIN`, decides which variant succeeded, and hands
 * over the raw payload untouched — text, JSON, or decoded rows re-serialised
 * as JSON. Everything that *interprets* that payload lives here, so the same
 * parsers back the desktop app and any standalone visualiser fed a pasted or
 * uploaded plan.
 *
 * Plugin drivers can register parsers for formats this package does not know;
 * `resolveExplainOutput` also accepts their historical fully-parsed shape.
 */

/** Wire formats supplied by Tabularis built-in drivers. */
type BuiltinRawExplainFormat = "postgres-json" | "mysql-json" | "mysql-analyze-text" | "mysql-tabular-rows" | "sqlite-eqp-rows";
/** Wire format supplied by a built-in or registered plugin driver. */
type RawExplainFormat = BuiltinRawExplainFormat | (string & {});
/** Raw EXPLAIN output produced by a built-in driver, parsed on this side. */
interface RawExplainOutput {
    /** Driver id of the engine that produced the payload ("postgres", …). */
    engine: string;
    format: RawExplainFormat;
    /** The untouched payload: text, a JSON document, or rows as a JSON array. */
    payload: string;
    original_query: string;
}
/**
 * What the host's `explain_query_plan` command returns: a raw payload from a
 * built-in driver, or a plan a plugin driver already parsed.
 */
type ExplainQueryOutput = {
    kind: "raw";
    raw: RawExplainOutput;
} | {
    kind: "plan";
    plan: ExplainPlan;
};

interface ForeignKey {
    name: string;
    column_name: string;
    ref_table: string;
    ref_column: string;
}
interface Index {
    name: string;
    column_name: string;
    is_unique: boolean;
    is_primary: boolean;
    seq_in_index?: number;
    is_expression?: boolean;
}

type NotebookCellType = "sql" | "markdown";
type ChartType = "bar" | "line" | "pie";
interface CellChartConfig {
    type: ChartType;
    labelColumn: string;
    valueColumns: string[];
}
interface NotebookParam {
    name: string;
    value: string;
}
interface CellExecutionEntry {
    query: string;
    result: QueryResult | null;
    error?: string;
    executionTime: number | null;
    timestamp: number;
}
interface NotebookCell {
    id: string;
    type: NotebookCellType;
    content: string;
    name?: string;
    schema?: string;
    result?: QueryResult | null;
    error?: string;
    executionTime?: number | null;
    isLoading?: boolean;
    isPreview?: boolean;
    chartConfig?: CellChartConfig | null;
    resultHeight?: number;
    isParallel?: boolean;
    isCollapsed?: boolean;
    isQueryCollapsed?: boolean;
    isResultCollapsed?: boolean;
    isChartVisible?: boolean;
    isQueryPlanVisible?: boolean;
    history?: CellExecutionEntry[];
}
interface NotebookState {
    cells: NotebookCell[];
    stopOnError?: boolean;
    params?: NotebookParam[];
}
interface NotebookMetadata {
    id: string;
    title: string;
    createdAt?: string;
    updatedAt?: string;
}

interface Pagination {
    page: number;
    page_size: number;
    total_rows: number | null;
    has_more: boolean;
}
interface TableColumn {
    name: string;
    data_type: string;
    is_pk: boolean;
    is_nullable: boolean;
    is_auto_increment: boolean;
    is_generated?: boolean;
    default_value?: string;
    character_maximum_length?: number;
    comment?: string | null;
}
interface TableSchema {
    name: string;
    columns: TableColumn[];
    foreign_keys: ForeignKey[];
}
interface QueryResult {
    columns: string[];
    rows: unknown[][];
    affected_rows: number;
    truncated?: boolean;
    pagination?: Pagination;
    additional_results?: QueryResult[];
}
interface BatchStatementResult {
    result: QueryResult | null;
    error: string | null;
    execution_time_ms: number | null;
}
interface QueryResultEntry {
    id: string;
    queryIndex: number;
    query: string;
    label?: string;
    result: QueryResult | null;
    error: string;
    executionTime: number | null;
    isLoading: boolean;
    page: number;
    activeTable: string | null;
    pkColumns: string[] | null;
}

interface FlowState {
    nodes: Node[];
    edges: Edge[];
}
interface PendingInsertion {
    tempId: string;
    data: Record<string, unknown>;
    displayIndex: number;
}
type AutoRefreshInterval = 0 | 5000 | 10000 | 30000 | 60000;
interface Tab {
    id: string;
    title: string;
    type: "console" | "table" | "query_builder" | "notebook" | "users";
    query: string;
    result: QueryResult | null;
    error: string;
    executionTime: number | null;
    page: number;
    activeTable: string | null;
    pkColumns: string[] | null;
    autoIncrementColumns?: string[];
    defaultValueColumns?: string[];
    nullableColumns?: string[];
    columnMetadata?: TableColumn[];
    foreignKeys?: ForeignKey[];
    isLoading?: boolean;
    autoRefreshIntervalMs?: AutoRefreshInterval;
    isAutoRefreshing?: boolean;
    autoRefreshError?: string;
    connectionId: string;
    flowState?: FlowState;
    pendingChanges?: Record<string, {
        pkOriginalValue: unknown;
        changes: Record<string, unknown>;
    }>;
    pendingDeletions?: Record<string, unknown>;
    pendingInsertions?: Record<string, PendingInsertion>;
    mutationNeedsReview?: boolean;
    selectedRows?: number[];
    isEditorOpen?: boolean;
    filterClause?: string;
    sortClause?: string;
    limitClause?: number;
    pageSize?: number;
    queryParams?: Record<string, string>;
    schema?: string;
    readOnly?: boolean;
    materialized?: boolean;
    results?: QueryResultEntry[];
    activeResultId?: string;
    notebookId?: string;
    notebookState?: NotebookState;
    sourceFilePath?: string;
    /** Content last read from / written to `sourceFilePath`; dirty = query differs from it. */
    sourceFileContent?: string;
    sourceFileDirty?: boolean;
}
interface EditorPreferences {
    tabs: Array<Partial<Tab>>;
    active_tab_id: string | null;
}

interface MonacoThemeDefinition {
    base: 'vs' | 'vs-dark' | 'hc-black';
    inherit: boolean;
    rules?: Array<{
        token: string;
        foreground?: string;
        background?: string;
        fontStyle?: string;
    }>;
    colors?: Record<string, string>;
    /** Optional: Name of the monaco-themes theme to use */
    themeName?: string;
}
interface ThemeColors {
    bg: {
        base: string;
        elevated: string;
        overlay: string;
        input: string;
        tooltip: string;
    };
    surface: {
        primary: string;
        secondary: string;
        tertiary: string;
        hover: string;
        active: string;
        disabled: string;
    };
    text: {
        primary: string;
        secondary: string;
        muted: string;
        disabled: string;
        accent: string;
        inverse: string;
    };
    accent: {
        primary: string;
        secondary: string;
        success: string;
        warning: string;
        error: string;
        info: string;
    };
    border: {
        subtle: string;
        default: string;
        strong: string;
        focus: string;
    };
    semantic: {
        string: string;
        number: string;
        boolean: string;
        date: string;
        null: string;
        primaryKey: string;
        foreignKey: string;
        index: string;
        connectionActive: string;
        connectionInactive: string;
        modified: string;
        deleted: string;
        new: string;
    };
}
interface ThemeTypography {
    fontFamily: {
        base: string;
        mono: string;
    };
    fontSize: {
        xs: string;
        sm: string;
        base: string;
        lg: string;
        xl: string;
    };
}
interface ThemeLayout {
    borderRadius: {
        sm: string;
        base: string;
        lg: string;
        xl: string;
    };
    spacing: {
        xs: string;
        sm: string;
        base: string;
        lg: string;
        xl: string;
    };
}
interface TaskbarIconConfig {
    type: 'tint' | 'custom';
    color?: string;
    iconPath?: string;
}
interface Theme {
    id: string;
    name: string;
    author?: string;
    version?: string;
    isPreset: boolean;
    isReadOnly: boolean;
    createdAt?: string;
    updatedAt?: string;
    colors: ThemeColors;
    typography: ThemeTypography;
    layout: ThemeLayout;
    monacoTheme: MonacoThemeDefinition;
    taskbarIcon?: TaskbarIconConfig;
}

/**
 * Single source of truth for supported languages.
 * Dictionaries are loaded separately by localeBackend when selected.
 */
declare const SUPPORTED_LANGUAGES: readonly [{
    readonly id: "en";
    readonly label: "English";
}, {
    readonly id: "it";
    readonly label: "Italiano";
}, {
    readonly id: "es";
    readonly label: "Español";
}, {
    readonly id: "zh";
    readonly label: "中文";
}, {
    readonly id: "fr";
    readonly label: "Français";
}, {
    readonly id: "de";
    readonly label: "Deutsch";
}, {
    readonly id: "ja";
    readonly label: "日本語";
}, {
    readonly id: "ru";
    readonly label: "Русский";
}, {
    readonly id: "ko";
    readonly label: "한국어";
}, {
    readonly id: "tl";
    readonly label: "Tagalog";
}, {
    readonly id: "pt-BR";
    readonly label: "Português (Brasil)";
}];
type AppLanguage = "auto" | (typeof SUPPORTED_LANGUAGES)[number]["id"];

type CopyFormat = "csv" | "json" | "sql-insert" | "markdown";
type AiProvider = "openai" | "anthropic" | "openrouter" | "ollama" | "custom-openai" | "minimax";
type ERDiagramLayout = "LR" | "TB";
type WindowDecorationsMode = "automatic" | "alwaysShow" | "alwaysHide";
interface PluginConfig {
    interpreter?: string;
    settings?: Record<string, unknown>;
    /** Per-plugin override of `pluginCallTimeoutSeconds`. Unset inherits the global value; 0 disables the timeout. */
    callTimeoutSeconds?: number;
}
/** One entry in the append-only driver-migration history. Kept even after an
 * undo so a filed issue has the before/after to attach. */
interface DriverMigrationRecord {
    /** Connection that was migrated. */
    connectionId: string;
    /** Driver id migrated from (e.g. the built-in "postgres"). */
    fromDriver: string;
    /** Driver id migrated to (e.g. the plugin "postgresql"). */
    toDriver: string;
    /** ISO-8601 timestamp of the migration. */
    migratedAt: string;
    /** Whether the post-migration "Switched — Undo" toast was dismissed. */
    toastDismissed?: boolean;
}
/** Whether a built-in driver's migration is opt-in or forced. Flipping to
 * "forced" is a separate, later decision; the default everywhere is "opt-in". */
type MigrationMode = "opt-in" | "forced";
interface Settings {
    resultPageSize: number;
    language: AppLanguage;
    /** IANA timezone name (e.g. "Asia/Tokyo") for rendering timestamps, or "auto" to follow the OS timezone. */
    displayTimezone?: string;
    fontFamily: string;
    fontSize: number;
    /** Colorize query result cell values by their data type. Default: false. */
    resultColorByType?: boolean;
    /** Per-type hex color overrides for result cell values (keys: number, string, date, boolean). */
    resultTypeColors?: Record<string, string>;
    /** Keep the result grid's column headers pinned to the top while scrolling. Default: true. */
    stickyColumnHeaders?: boolean;
    /** Shade every other result grid row for easier scanning. Default: false. */
    resultZebraStripes?: boolean;
    /** Font used for query result cells. A font name from AVAILABLE_FONTS, a custom family, or RESULT_FONT_INHERIT to follow the interface font. Default: "JetBrains Mono". */
    resultFontFamily?: string;
    aiEnabled: boolean;
    aiProvider: AiProvider | null;
    aiModel: string | null;
    aiCustomModels?: Record<string, string[]>;
    aiOllamaPort?: number;
    aiCustomOpenaiUrl?: string;
    aiCustomOpenaiModel?: string;
    autoCheckUpdatesOnStartup?: boolean;
    /** Last plugin release shown in a startup notification, keyed by plugin id. */
    notifiedPluginVersions?: Record<string, string>;
    releaseChannel?: "stable" | "nightly";
    loggingEnabled?: boolean;
    maxLogEntries?: number;
    erDiagramDefaultLayout?: ERDiagramLayout;
    copyFormat?: CopyFormat;
    csvDelimiter?: string;
    /** Whether copied CSV output includes a header row. Default: true. */
    csvIncludeHeaders?: boolean;
    /** Whether the row editor sidebar follows row selection. Default: true. */
    rowEditorFollowSelection?: boolean;
    /** What happens on double-click of a data cell: "inline" (edit in place), "sidebar" (open in row editor), "both" (inline + update sidebar). Default: "inline". */
    cellDoubleClickAction?: "inline" | "sidebar" | "both";
    activeExternalDrivers?: string[];
    /** Base URL of the Tabularium plugin registry. Defaults to the built-in instance when unset. */
    tabulariumRegistryUrl?: string;
    plugins?: Record<string, PluginConfig>;
    /** Seconds the host waits for a plugin to answer a single call. 0 disables the timeout. Default: 120. */
    pluginCallTimeoutSeconds?: number;
    editorTheme?: string;
    editorFontFamily?: string;
    editorFontSize?: number;
    editorLineHeight?: number;
    editorTabSize?: number;
    editorWordWrap?: boolean;
    editorShowLineNumbers?: boolean;
    editorAcceptSuggestionOnEnter?: boolean;
    runStatementUnderCursor?: boolean;
    /** Delay destructive-query and production-write confirmations for five seconds. Default: false. */
    safetyConfirmationDelayEnabled?: boolean;
    /** Send a desktop notification when a long-running query finishes while the window is unfocused. Default: true. */
    notifyLongQueries?: boolean;
    /** Minimum execution time in seconds before a finished query triggers a notification. Default: 20. */
    notifyLongQueriesThresholdSec?: number;
    formatterKeywordCase?: "upper" | "lower" | "preserve";
    formatterIndentStyle?: "standard" | "tabularLeft" | "tabularRight";
    formatterTabWidth?: number;
    formatterUseTabs?: boolean;
    formatterFunctionCase?: "upper" | "lower" | "preserve";
    formatterLinesBetweenQueries?: number;
    formatterDenseOperators?: boolean;
    pingInterval?: number;
    queryHistoryMaxEntries?: number;
    showWelcome?: boolean;
    /** Reconnect to the last active connection on startup. Default: true. */
    autoConnectLastConnection?: boolean;
    /** Maximize the window on startup. Default: false. */
    startMaximized?: boolean;
    /** Controls whether Tauri uses native window decorations. */
    windowDecorations?: WindowDecorationsMode;
    aiAuditEnabled?: boolean;
    aiAuditMaxEntries?: number;
    aiSessionGapMinutes?: number;
    mcpOutputFormat?: "json" | "toon";
    mcpReadonlyDefault?: boolean;
    mcpReadonlyConnections?: string[];
    mcpApprovalMode?: "off" | "writes_only" | "all";
    mcpApprovalTimeoutSeconds?: number;
    mcpPreflightExplain?: boolean;
    mcpApprovalAlwaysOnTop?: boolean;
    mcpApprovalNotifySound?: boolean;
    /** When backups run: "manual" (default), "interval", "onClose" or "onLaunch". */
    backupMode?: "manual" | "interval" | "onClose" | "onLaunch";
    /** Directory the backup files are written to. */
    backupDirectory?: string;
    /** Minutes between automatic backups in interval mode. Default: 1440. */
    backupIntervalMinutes?: number;
    /** Number of backup files kept before rotation. Default: 10. */
    backupRetention?: number;
    /** Backup destination: "local" (default) or "webdav". */
    backupTarget?: "local" | "webdav";
    /** WebDAV collection URL the backups are uploaded into. */
    backupWebdavUrl?: string;
    /** WebDAV username; the password lives in the OS keychain. */
    backupWebdavUsername?: string;
    /** Mask values of sensitive columns in the results grid (display only). Default: true. */
    columnMaskingEnabled?: boolean;
    /** Column-name patterns (case-insensitive substring) that trigger masking. */
    columnMaskingPatterns?: string[];
    /** Per-connection `table.column` include/exclude overrides, keyed by connection id. */
    columnMaskingOverrides?: Record<string, {
        include?: string[];
        exclude?: string[];
    }>;
    /** Whether the user has dismissed the PostgreSQL-plugin migration banner.
     * Absent/undefined → banner is eligible to show. Resurfaces automatically
     * if a builtin-postgres connection appears that wasn't in
     * `postgresPluginMigrationBannerDismissedFor` at dismissal time — the same
     * "did-the-condition-change" gating `WhatsNewModal` uses for its own
     * version comparison. */
    postgresPluginMigrationBannerDismissed?: boolean;
    /** Connection ids that existed (on the builtin driver) at the moment the
     * banner was dismissed. A builtin connection id not in this list means the
     * trigger condition changed since the dismissal, so the banner shows again. */
    postgresPluginMigrationBannerDismissedFor?: string[];
    /** Append-only record of every connection migrated between built-in and
     * plugin drivers. Kept even after an undo. */
    driverMigrationHistory?: DriverMigrationRecord[];
    /** Map of pluginId → list of capability-gap feature names already reported,
     * so the same user isn't prompted to re-report a gap already filed. */
    knownCapabilityGaps?: Record<string, string[]>;
    /** Per built-in driver id → migration mode. Defaults to "opt-in" when unset;
     * flipping an entry to "forced" is a separate, later decision. */
    migrationModeByDriver?: Record<string, MigrationMode>;
    /** Global HTTP/SOCKS5 proxy and opt-in traffic scopes. */
    proxy?: GlobalProxySettings;
    /** Per AI-provider proxy overrides. */
    aiProviderProxies?: Partial<Record<AiProvider, ProxyOverride>>;
}

interface SavedQuery {
    id: string;
    name: string;
    sql: string;
    connection_id: string;
    database: string | null;
    created_at: string | null;
    updated_at: string | null;
}

interface QueryHistoryEntry {
    id: string;
    sql: string;
    executedAt: string;
    executionTimeMs: number | null;
    status: "success" | "error";
    rowsAffected: number | null;
    error: string | null;
    database: string | null;
}
interface QueryHistoryResponse {
    entries: QueryHistoryEntry[];
    recoveredBackupPath: string | null;
}

interface KeyMatch {
    key: string;
    code?: string;
    ctrlKey?: boolean;
    metaKey?: boolean;
    shiftKey?: boolean;
    altKey?: boolean;
}
type UserOverrides = Record<string, {
    mac: KeyMatch;
    win: KeyMatch;
}>;

type AiQueryKind = "select" | "write" | "ddl" | "unknown";
interface AiKeyStatus {
    configured: boolean;
    fromEnv: boolean;
}
type AiProviderModels = Record<string, string[]>;
interface AiGenerateRequest {
    provider: string;
    model: string;
    prompt: string;
    schema: string;
}
interface AiExplainRequest {
    provider: string;
    model: string;
    query: string;
    language: string;
}
interface AiNameRequest {
    provider: string;
    model: string;
    query: string;
}
interface AiTableNameRequest {
    provider: string;
    model: string;
    headers: string[];
    sample_rows: string[][];
}
type AiActivityStatus = "success" | "blocked_readonly" | "blocked_pending_approval" | "denied" | "error" | "timeout";
type AiToolName = "list_connections" | "list_databases" | "list_tables" | "describe_table" | "run_query" | (string & {});
interface AiActivityEvent {
    id: string;
    sessionId: string;
    timestamp: string;
    tool: AiToolName;
    connectionId: string | null;
    connectionName: string | null;
    query: string | null;
    queryKind: AiQueryKind | null;
    durationMs: number;
    status: AiActivityStatus;
    rows: number | null;
    error: string | null;
    clientHint: string | null;
    approvalId: string | null;
}
interface AiSessionSummary {
    sessionId: string;
    startedAt: string;
    endedAt: string;
    eventCount: number;
    runQueryCount: number;
    connectionNames: string[];
    clientHint: string | null;
}
interface AiEventFilter {
    sessionId?: string;
    connectionId?: string;
    tool?: string;
    status?: AiActivityStatus;
    queryContains?: string;
    since?: string;
    until?: string;
}
interface PendingApproval {
    id: string;
    createdAt: string;
    sessionId: string;
    connectionId: string;
    connectionName: string;
    query: string;
    queryKind: AiQueryKind;
    clientHint: string | null;
    explainPlan: unknown | null;
    explainError: string | null;
}
type ApprovalDecisionKind = "approve" | "deny";
interface ApprovalDecisionPayload {
    approvalId: string;
    decision: ApprovalDecisionKind;
    reason?: string;
    editedQuery?: string;
}
interface AiNotebookExportCell {
    type: "sql" | "markdown";
    content: string;
    name?: string;
    schema?: string;
}
interface AiNotebookExport {
    version: number;
    title: string;
    createdAt: string;
    cells: AiNotebookExportCell[];
}

/**
 * Types for importing connections from other installed SQL clients.
 * Mirror the Rust structs in `src-tauri/src/connection_import_commands.rs`
 * and `connection_import/analyzer.rs` / `convert.rs`.
 */
interface ImportSourceInfo {
    id: string;
    displayName: string;
    available: boolean;
    connectionCount: number;
    readsPasswordsFromKeychain: boolean;
    needsFile: boolean;
    manualPathSupported: boolean;
}
type ImportItemStatus = {
    kind: "ready";
} | {
    kind: "duplicate";
    existingId: string;
    existingName: string;
} | {
    kind: "warnings";
    warnings: string[];
};
interface ImportItem {
    index: number;
    name: string;
    driverId: string;
    driverInstalled: boolean;
    host: string;
    port: number;
    database: string;
    username: string;
    hasSsh: boolean;
    hasPassword: boolean;
    groupName?: string;
    status: ImportItemStatus;
}
interface ImportPreview {
    sourceName: string;
    credentialsAborted: boolean;
    items: ImportItem[];
}
/** Per-item disposition sent back to `apply_connection_import`. */
type ImportAction = "import" | "skip" | "replace";
interface ImportResolution {
    index: number;
    action: ImportAction;
    replaceExistingId?: string;
    /**
     * Target group for a newly-imported connection. An id assigns to that
     * existing group; `""` means "no group"; omitted falls back to the source
     * app's folder. Ignored for `replace`.
     */
    groupId?: string;
    /** Name of a group to create (or reuse by name). Wins over `groupId`. */
    newGroupName?: string;
    /** Existing group id to nest `newGroupName` under. Omitted → top level. */
    newGroupParentId?: string;
}

type RequestId = string;

interface LogEntry {
    timestamp: string;
    level: string;
    message: string;
    target?: string | null;
}
interface LogSettings {
    enabled: boolean;
    max_size: number;
    current_count: number;
}
interface ChildProcessInfo {
    pid: number;
    cpu_percent: number;
    memory_bytes: number;
    disk_read_bytes: number;
    disk_write_bytes: number;
}
interface ProcessInfo {
    plugin_id: string;
    plugin_name: string;
    pid: number | null;
    cpu_percent: number;
    memory_bytes: number;
    disk_read_bytes: number;
    disk_write_bytes: number;
    status: "running" | "stopped" | "unknown";
    children: ChildProcessInfo[];
}
interface TabularisChildProcess {
    pid: number;
    name: string;
    cpu_percent: number;
    memory_bytes: number;
}
interface TabularisSelfStats {
    pid: number;
    cpu_percent: number;
    self_memory_bytes: number;
    total_memory_bytes: number;
    disk_read_bytes: number;
    disk_write_bytes: number;
    child_count: number;
}
interface SystemStats {
    cpu_percent: number;
    memory_used: number;
    memory_total: number;
    disk_read_bytes: number;
    disk_write_bytes: number;
    process_count: number;
    tabularis: TabularisSelfStats | null;
}

interface McpClientStatus {
    client_id: string;
    client_name: string;
    installed: boolean;
    config_path: string | null;
    executable_path: string;
    client_type: "file" | "command";
    manual_command?: string | null;
}

/** Native-issued identity, never copied from author-supplied origin flags. */
interface InstalledThemeIdentity {
    /** Lowercase SHA-256 of the native-canonicalized registry URL. */
    registryKey: string;
    packageName: string;
    variantId: string;
}
type ThemePackageMode = "light" | "dark" | "high-contrast";
interface ThemePackageManifestV1 {
    /** Editor hint only; never used to select or fetch the validation schema. */
    $schema?: string;
    /** Stable package identifier (slug). Without it, `name` is the identifier. */
    id?: string;
    /** Display name; free-form only when `id` is declared. */
    name: string;
    version: string;
    kind: "theme";
    min_runtime_version: string;
    theme_schema_version: 1;
    theme_variants: Array<{
        id: string;
        name: string;
        file: string;
    }>;
    description?: string;
    category?: string;
    tags?: string[];
    license?: string;
    icon?: string;
    screenshots?: Array<{
        url: string;
        caption?: string;
        alt?: string;
    }>;
    readme?: string;
    readmes?: Record<string, string>;
    documentation_url?: string;
    homepage?: string;
    support?: {
        email?: string;
        issues_url?: string;
    };
}
/** Supplied by a trusted native catalog or the host's builtin adapter. */
type ThemeContributionOrigin = {
    kind: "builtin";
} | {
    kind: "personal";
} | {
    kind: "installed";
    identity: InstalledThemeIdentity;
    packageVersion: string;
};
interface ThemeContributionContext {
    id: string;
    name: string;
    revision: string;
    origin: ThemeContributionOrigin;
    author?: string;
}

interface NativeThemeContribution extends ThemeContributionContext {
    readOnly: boolean;
    mode: ThemePackageMode;
    format: "legacy" | "v1";
    source: string;
    available: boolean;
    editor?: MonacoThemeDefinition | null;
}
/** Validated local archive, returned before the user confirms the install. */
interface LocalThemePreview {
    digest: string;
    manifest: ThemePackageManifestV1;
    variants: NativeThemeContribution[];
}
/** A committed package operation; warnings describe deferred cleanup only. */
interface ThemeCommit {
    warnings: string[];
}
interface NativeThemeCatalog {
    themes: NativeThemeContribution[];
    issues: string[];
}

interface ThemeRegistryRelease {
    version: string;
    min_tabularis_version: string | null;
    assets: Record<string, string>;
}
interface ThemeRegistryPlugin extends Pick<RegistryPluginWithStatus, "id" | "name" | "author" | "description" | "latest_version" | "downloads"> {
    releases: ThemeRegistryRelease[];
    screenshots?: Array<{
        url: string;
        alt?: string | null;
        caption?: string | null;
    }>;
}
interface ThemeRegistrySnapshot {
    registryKey: string;
    registryUrl: string;
    plugins: ThemeRegistryPlugin[];
}

/** Where the folder in use was resolved from (mirrors the Rust enum). */
type StorageLocationSource = "default" | "custom" | "env";
interface StorageLocationInfo {
    /** Folder the running app is actually using. */
    currentPath: string;
    /** Platform default folder. */
    defaultPath: string;
    /** Folder recorded by the user, if any. */
    customPath: string | null;
    source: StorageLocationSource;
    /** The recorded folder differs from the one in use: restart to apply. */
    restartRequired: boolean;
}
interface StorageLocationInspection {
    exists: boolean;
    isEmpty: boolean;
    hasTabularisData: boolean;
}

type AuthorizationLevel = "session" | "database" | "sensitive" | "local-admin";
interface CommandDefinition<Request, Response, Authorization extends AuthorizationLevel> {
    readonly request: Request;
    readonly response: Response;
    readonly authorization: Authorization;
}
interface ServerPathEntry {
    readonly name: string;
    readonly path: string;
    readonly kind: "file" | "directory";
}
interface ServerDirectoryListing {
    readonly path: string | null;
    readonly parent: string | null;
    readonly entries: readonly ServerPathEntry[];
}
interface ListServerDirectoryRequest {
    readonly path?: string;
}
interface ResolveServerSaveTargetRequest {
    readonly directory: string;
    readonly fileName: string;
}
interface ServerSaveTarget {
    readonly path: string;
}
interface SqlitePathRequest {
    readonly path: string;
}
/**
 * A local theme archive. Desktop sends a host path from the native dialog;
 * browsers send either an upload token (purpose {@link THEME_PACKAGE_UPLOAD_PURPOSE})
 * or a server path chosen with the server file browser.
 */
type LocalThemeArchiveRequest = {
    readonly path: string;
    readonly uploadToken?: never;
} | {
    readonly uploadToken: string;
    readonly path?: never;
};
interface ThemePackageRequest {
    readonly registryKey: string;
    readonly packageName: string;
}
/** Values stored in the shared UI state database, keyed by UI state key. */
type UiStateEntries = Readonly<Record<string, unknown>>;
interface ConnectionParameters {
    driver: string;
    database: string | string[];
    host?: string;
    port?: number;
    username?: string;
    password?: string;
    connection_uri?: string;
    connection_uri_in_keychain?: boolean;
    ssl_mode?: string;
    ssl_ca?: string;
    ssl_cert?: string;
    ssl_key?: string;
    enable_cleartext_plugin?: boolean;
    pipes_as_concat?: boolean;
    use_iam_auth?: boolean;
    ssh_enabled?: boolean;
    ssh_connection_id?: string;
    ssh_host?: string;
    ssh_port?: number;
    ssh_user?: string;
    ssh_password?: string;
    ssh_key_file?: string;
    ssh_key_passphrase?: string;
    ssh_allow_passphrase_prompt?: boolean;
    save_in_keychain?: boolean;
    k8s_enabled?: boolean;
    k8s_connection_id?: string;
    k8s_context?: string;
    k8s_namespace?: string;
    k8s_resource_type?: string;
    k8s_resource_name?: string;
    k8s_port?: number;
    k8s_kubectl_path?: string;
    k8s_kubeconfig_path?: string;
    startup_script?: string;
    extra?: Record<string, string>;
    connection_id?: string;
}
interface TestConnectionRequest {
    params: ConnectionParameters;
    connection_id?: string;
    progress_id?: string;
}
interface SshConnection {
    id: string;
    name: string;
    host: string;
    port: number;
    user: string;
    auth_type?: "password" | "ssh_key";
    password?: string;
    key_file?: string;
    key_passphrase?: string;
    allow_passphrase_prompt?: boolean;
    save_in_keychain?: boolean;
}
type SshConnectionInput = Partial<Omit<SshConnection, "id" | "name">>;
interface SshTestRequest extends Partial<SshConnection> {
    connection_id?: string;
    db_connection_id?: string;
    progress_id?: string;
}
interface K8sConnection {
    id: string;
    name: string;
    context: string;
    namespace: string;
    resource_type: "service" | "pod";
    resource_name: string;
    port: number;
    kubectl_path?: string;
    kubeconfig_path?: string;
}
interface K8sConnectionInput {
    name: string;
    context: string;
    namespace: string;
    resource_type: string;
    resource_name: string;
    port: number;
    kubectl_path?: string;
    kubeconfig_path?: string;
}
interface K8sCommandRequest {
    kubectlPath?: string;
    kubeconfigPath?: string;
}
interface SaveConnectionRequest {
    name: string;
    params: ConnectionParameters;
    detectJsonInTextColumns?: boolean;
    environment?: string;
}
interface UpdateConnectionRequest extends SaveConnectionRequest {
    id: string;
}
interface ConnectionIdRequest {
    connectionId: string;
}
interface NotebookTargetRequest extends ConnectionIdRequest {
    notebookId: string;
}
interface NotebookContentRequest extends NotebookTargetRequest {
    content: string;
}
interface MetadataRequest extends ConnectionIdRequest {
    schema?: string;
}
interface TableMetadataRequest extends MetadataRequest {
    tableName: string;
}
interface ViewMetadataRequest extends MetadataRequest {
    viewName: string;
}
interface ExecuteQueryRequest extends MetadataRequest {
    sessionId?: string;
    query: string;
    limit?: number;
    page?: number;
}
interface ExecuteQueryBatchRequest extends MetadataRequest {
    sessionId?: string;
    queries: string[];
    limit?: number;
    page?: number;
    batchId?: string;
}
interface ExplainQueryRequest extends MetadataRequest {
    query: string;
    analyze: boolean;
}
interface CancelQueryRequest extends ConnectionIdRequest {
    queryRequestId?: RequestId;
}
interface RecordLocator extends MetadataRequest {
    table: string;
    database?: string;
}
interface RecordIdentityRequest extends RecordLocator {
    pkMap: Record<string, unknown>;
}
interface BlobColumnRequest extends RecordIdentityRequest {
    colName: string;
}
interface ColumnDefinition {
    name: string;
    data_type: string;
    is_nullable: boolean;
    is_pk: boolean;
    is_auto_increment: boolean;
    default_value: string | null;
}
interface RoutineParameterInfo {
    name: string;
    data_type: string;
    mode: string;
    ordinal_position: number;
}
interface RoutineCallArg {
    name: string;
    mode: string;
    value: string | null;
    is_raw: boolean;
}
interface DbUserInfo {
    user: string;
    host: string;
    locked: boolean;
}
interface DbPrivilegeCatalog {
    database: string[];
    global: string[];
    table: string[];
}
interface DbUserGrantSet {
    database: string | null;
    table: string | null;
    privileges: string[];
}
interface RoutineTargetRequest extends MetadataRequest {
    routineName: string;
    routineType: string;
}
interface TriggerTargetRequest extends MetadataRequest {
    triggerName: string;
    tableName: string;
}
interface DbUserTargetRequest extends ConnectionIdRequest {
    user: string;
    host: string;
}
type BlobFetchResponse = {
    kind: "inline";
    wireValue: string;
} | {
    kind: "download";
    token: string;
    size: number;
    mimeType: string;
};
type ConnectionExportMode = "encrypted" | "noSecrets" | "plaintext";
type GeneratedFile = {
    kind: "inline";
    fileName: string;
    mimeType: string;
    contents: string;
} | {
    kind: "download";
    fileName: string;
    mimeType: string;
    token: string;
    size: number;
};
type ConnectionImportFile = {
    kind: "serverPath";
    path: string;
} | {
    kind: "upload";
    token: string;
};
type TabularisImportPreviewResult = {
    kind: "passwordRequired";
} | {
    kind: "preview";
    preview: ImportPreview;
};
interface BackupStatus {
    passwordSet: boolean;
    targetPasswordSet: boolean;
    lastBackupAt: string | null;
    targetKind: "serverDirectory" | "webdav";
    targetDisplay: string | null;
}
interface BackupRunResult {
    serverLocation: string;
    targetKind: "serverDirectory" | "webdav";
    download: GeneratedFile | null;
}
interface DumpOptions {
    structure: boolean;
    data: boolean;
    tables?: string[] | null;
}
interface DatabaseDumpRequest extends ConnectionIdRequest {
    options: DumpOptions;
    schema?: string;
    database?: string;
    /** Desktop-only save path. Browser requests omit this and receive a download. */
    filePath?: string;
}
interface DatabaseImportRequest extends ConnectionIdRequest {
    schema?: string;
    database?: string;
    /** Desktop-only source path. */
    filePath?: string;
    /** Browser-only opaque upload token. */
    uploadToken?: string;
}
interface QueryExportRequest extends ConnectionIdRequest {
    sessionId?: string;
    query: string;
    format: "csv" | "json" | "markdown";
    csvDelimiter?: string;
    database?: string;
    /** Desktop-only save path. Browser requests omit this and receive a download. */
    filePath?: string;
}
interface PersistedConfig extends Partial<Settings> {
    theme?: string;
    followSystemTheme?: boolean;
    lightThemeId?: string;
    darkThemeId?: string;
    checkForUpdates?: boolean;
    lastDismissedVersion?: string;
    lastActiveConnectionId?: string;
    lastOpenConnectionIds?: string[];
}
interface CommandMap {
    get_table_query_template: CommandDefinition<ConnectionIdRequest & {
        request: TableQueryTemplateRequest;
    }, string | null, "database">;
    release_query_session: CommandDefinition<ConnectionIdRequest & {
        sessionId: string;
    }, void, "database">;
    set_selected_databases: CommandDefinition<ConnectionIdRequest & {
        databases: string[];
    }, void, "database">;
    log_frontend_event: CommandDefinition<{
        level: string;
        message: string;
    }, void, "session">;
    get_data_types: CommandDefinition<{
        driver: string;
    }, DataTypeRegistry, "database">;
    map_inferred_column_types: CommandDefinition<{
        driver: string;
        connectionId?: string;
        kinds: string[];
    }, string[], "database">;
    execute_clipboard_import: CommandDefinition<{
        req: {
            connection_id: string;
            table_name: string;
            schema: string | null;
            columns: ColumnDefinition[];
            rows: Array<Array<string | null>>;
            create_table: boolean;
            if_exists: "fail" | "append" | "replace";
            add_columns: ColumnDefinition[];
        };
    }, {
        rows_inserted: number;
        table_created: boolean;
    }, "database">;
    is_debug_mode: CommandDefinition<undefined, boolean, "local-admin">;
    list_server_directory: CommandDefinition<ListServerDirectoryRequest, ServerDirectoryListing, "local-admin">;
    resolve_server_save_target: CommandDefinition<ResolveServerSaveTargetRequest, ServerSaveTarget, "local-admin">;
    create_sqlite_file: CommandDefinition<SqlitePathRequest, string, "local-admin">;
    create_sqlite_database: CommandDefinition<SqlitePathRequest, SavedConnection, "local-admin">;
    get_installation_source: CommandDefinition<undefined, string | null, "local-admin">;
    get_mcp_status: CommandDefinition<undefined, McpClientStatus[], "local-admin">;
    install_mcp_config: CommandDefinition<{
        clientId: string;
    }, string, "local-admin">;
    get_logs: CommandDefinition<{
        request: {
            limit?: number | null;
            level_filter?: string | null;
        };
    }, LogEntry[], "sensitive">;
    clear_logs: CommandDefinition<undefined, void, "local-admin">;
    get_log_settings: CommandDefinition<undefined, LogSettings, "sensitive">;
    set_log_enabled: CommandDefinition<{
        enabled: boolean;
    }, void, "local-admin">;
    set_log_max_size: CommandDefinition<{
        maxSize: number;
    }, void, "local-admin">;
    get_process_list: CommandDefinition<undefined, ProcessInfo[], "sensitive">;
    get_system_stats: CommandDefinition<undefined, SystemStats, "sensitive">;
    get_tabularis_children: CommandDefinition<undefined, TabularisChildProcess[], "sensitive">;
    get_connections: CommandDefinition<undefined, SavedConnection[], "database">;
    get_connection_by_id: CommandDefinition<{
        id: string;
    }, SavedConnection, "database">;
    get_connections_with_groups: CommandDefinition<undefined, ConnectionsFile, "database">;
    get_active_connections: CommandDefinition<undefined, string[], "database">;
    register_active_connection: CommandDefinition<ConnectionIdRequest, void, "database">;
    save_connection: CommandDefinition<SaveConnectionRequest, SavedConnection, "database">;
    update_connection: CommandDefinition<UpdateConnectionRequest, SavedConnection, "database">;
    delete_connection: CommandDefinition<{
        id: string;
    }, void, "database">;
    duplicate_connection: CommandDefinition<{
        id: string;
    }, SavedConnection, "database">;
    set_connection_appearance: CommandDefinition<{
        id: string;
        appearance?: ConnectionAppearance;
    }, void, "database">;
    save_connection_icon: CommandDefinition<{
        connectionId: string;
        uploadToken: string;
    }, string, "database">;
    delete_connection_icon: CommandDefinition<{
        relativePath: string;
    }, void, "database">;
    get_connection_groups: CommandDefinition<undefined, ConnectionGroup[], "database">;
    create_connection_group: CommandDefinition<{
        name: string;
        parentId?: string | null;
    }, ConnectionGroup, "database">;
    create_group_path: CommandDefinition<{
        path: string;
        parentId?: string | null;
    }, ConnectionGroup, "database">;
    update_connection_group: CommandDefinition<{
        id: string;
        name?: string;
        collapsed?: boolean;
        sortOrder?: number;
    }, ConnectionGroup, "database">;
    move_group_to_parent: CommandDefinition<{
        id: string;
        parentId: string | null;
    }, ConnectionGroup, "database">;
    delete_connection_group: CommandDefinition<{
        id: string;
    }, void, "database">;
    move_connection_to_group: CommandDefinition<{
        connectionId: string;
        groupId: string | null;
        sortOrder?: number;
    }, SavedConnection, "database">;
    reorder_groups: CommandDefinition<{
        groupOrders: Array<[string, number]>;
    }, void, "database">;
    reorder_connections_in_group: CommandDefinition<{
        connectionOrders: Array<[string, number]>;
    }, void, "database">;
    list_connection_tags: CommandDefinition<undefined, ConnectionTag[], "database">;
    create_connection_tag: CommandDefinition<{
        name: string;
        color: string;
    }, ConnectionTag, "database">;
    update_connection_tag: CommandDefinition<{
        id: string;
        name: string;
        color: string;
    }, void, "database">;
    delete_connection_tag: CommandDefinition<{
        id: string;
    }, void, "database">;
    set_connection_tags: CommandDefinition<{
        connectionId: string;
        tagIds: string[];
    }, void, "database">;
    get_registered_drivers: CommandDefinition<undefined, PluginManifest[], "database">;
    get_driver_manifest: CommandDefinition<{
        driverId: string;
    }, PluginManifest | null, "database">;
    fetch_plugin_registry: CommandDefinition<undefined, RegistryPluginWithStatus[], "local-admin">;
    fetch_tabularium_plugin_preview: CommandDefinition<{
        slug: string;
        registryUrl?: string | null;
        version?: string | null;
    }, RegistryPluginWithStatus, "local-admin">;
    fetch_plugin_readme: CommandDefinition<{
        slug: string;
        locale?: string | null;
        registryUrl?: string | null;
    }, PluginReadme, "local-admin">;
    install_plugin: CommandDefinition<{
        pluginId: string;
        version?: string | null;
        registryUrl?: string | null;
    }, void, "local-admin">;
    cancel_plugin_install: CommandDefinition<{
        pluginId: string;
    }, boolean, "local-admin">;
    uninstall_plugin: CommandDefinition<{
        pluginId: string;
    }, void, "local-admin">;
    get_installed_plugins: CommandDefinition<undefined, InstalledPluginInfo[], "local-admin">;
    disable_plugin: CommandDefinition<{
        pluginId: string;
    }, void, "local-admin">;
    enable_plugin: CommandDefinition<{
        pluginId: string;
    }, void, "local-admin">;
    get_plugin_manifest: CommandDefinition<{
        pluginId: string;
    }, PluginManifest, "local-admin">;
    get_plugin_startup_errors: CommandDefinition<undefined, PluginLoadError[], "local-admin">;
    kill_plugin_process: CommandDefinition<{
        pluginId: string;
    }, void, "local-admin">;
    restart_plugin_process: CommandDefinition<{
        pluginId: string;
    }, void, "local-admin">;
    test_connection: CommandDefinition<{
        request: TestConnectionRequest;
    }, string, "database">;
    disconnect_connection: CommandDefinition<ConnectionIdRequest, void, "database">;
    export_connections_file: CommandDefinition<{
        mode: ConnectionExportMode;
        password?: string;
        connectionIds?: string[] | null;
    }, GeneratedFile, "sensitive">;
    list_connection_import_sources: CommandDefinition<undefined, ImportSourceInfo[], "local-admin">;
    preview_connection_import: CommandDefinition<{
        sourceId: string;
        includePasswords: boolean;
        file?: ConnectionImportFile | null;
    }, ImportPreview, "local-admin">;
    apply_connection_import: CommandDefinition<{
        sourceId: string;
        resolutions: ImportResolution[];
    }, void, "local-admin">;
    preview_tabularis_import_file: CommandDefinition<{
        file: ConnectionImportFile;
        password?: string;
    }, TabularisImportPreviewResult, "sensitive">;
    apply_prepared_tabularis_import: CommandDefinition<{
        resolutions: ImportResolution[];
    }, void, "sensitive">;
    get_connections_backup_status: CommandDefinition<undefined, BackupStatus, "local-admin">;
    set_connections_backup_password: CommandDefinition<{
        password: string;
    }, void, "sensitive">;
    set_connections_backup_target_password: CommandDefinition<{
        targetId: string;
        password: string;
    }, void, "sensitive">;
    run_connections_backup: CommandDefinition<undefined, string | BackupRunResult, "sensitive">;
    dump_database: CommandDefinition<DatabaseDumpRequest, GeneratedFile | null, "sensitive">;
    cancel_dump: CommandDefinition<ConnectionIdRequest, void, "sensitive">;
    import_database: CommandDefinition<DatabaseImportRequest, void, "sensitive">;
    cancel_import: CommandDefinition<ConnectionIdRequest, void, "sensitive">;
    get_ssh_connections: CommandDefinition<undefined, SshConnection[], "local-admin">;
    save_ssh_connection: CommandDefinition<{
        name: string;
        ssh: SshConnectionInput;
    }, SshConnection, "local-admin">;
    update_ssh_connection: CommandDefinition<{
        id: string;
        name: string;
        ssh: SshConnectionInput;
    }, SshConnection, "local-admin">;
    delete_ssh_connection: CommandDefinition<{
        id: string;
    }, void, "local-admin">;
    test_ssh_connection: CommandDefinition<{
        ssh: SshTestRequest;
    }, string, "local-admin">;
    respond_ssh_askpass: CommandDefinition<{
        id: number;
        response: string | null;
    }, void, "sensitive">;
    get_k8s_connections: CommandDefinition<undefined, K8sConnection[], "local-admin">;
    save_k8s_connection: CommandDefinition<{
        k8s: K8sConnectionInput;
    }, K8sConnection, "local-admin">;
    update_k8s_connection: CommandDefinition<{
        id: string;
        k8s: K8sConnectionInput;
    }, K8sConnection, "local-admin">;
    delete_k8s_connection: CommandDefinition<{
        id: string;
    }, void, "local-admin">;
    test_k8s_connection_cmd: CommandDefinition<{
        context: string;
        namespace: string;
    } & K8sCommandRequest, string, "local-admin">;
    get_k8s_contexts_cmd: CommandDefinition<K8sCommandRequest | undefined, string[], "local-admin">;
    get_k8s_namespaces_cmd: CommandDefinition<{
        context: string;
    } & K8sCommandRequest, string[], "local-admin">;
    get_k8s_resources_cmd: CommandDefinition<{
        context: string;
        namespace: string;
        resourceType: string;
    } & K8sCommandRequest, string[], "local-admin">;
    get_k8s_resource_ports_cmd: CommandDefinition<{
        context: string;
        namespace: string;
        resourceType: string;
        resourceName: string;
    } & K8sCommandRequest, number[], "local-admin">;
    validate_k8s_path_cmd: CommandDefinition<{
        path: string;
        kind: "kubectl" | "kubeconfig";
    }, void, "local-admin">;
    get_available_databases: CommandDefinition<ConnectionIdRequest, string[], "database">;
    list_databases: CommandDefinition<{
        request: TestConnectionRequest;
    }, string[], "database">;
    get_schemas: CommandDefinition<ConnectionIdRequest, string[], "database">;
    get_tables: CommandDefinition<MetadataRequest, TableInfo[], "database">;
    get_columns: CommandDefinition<TableMetadataRequest, TableColumn[], "database">;
    get_foreign_keys: CommandDefinition<TableMetadataRequest, ForeignKey[], "database">;
    get_indexes: CommandDefinition<TableMetadataRequest, Index[], "database">;
    get_views: CommandDefinition<MetadataRequest, ViewInfo[], "database">;
    get_view_columns: CommandDefinition<ViewMetadataRequest, TableColumn[], "database">;
    get_materialized_views: CommandDefinition<MetadataRequest, ViewInfo[], "database">;
    get_materialized_view_columns: CommandDefinition<ViewMetadataRequest, TableColumn[], "database">;
    get_materialized_view_definition: CommandDefinition<ViewMetadataRequest, string, "database">;
    get_routines: CommandDefinition<MetadataRequest, RoutineInfo[], "database">;
    get_triggers: CommandDefinition<MetadataRequest, TriggerInfo[], "database">;
    get_schema_snapshot: CommandDefinition<MetadataRequest, TableSchema[], "database">;
    get_selected_schemas: CommandDefinition<ConnectionIdRequest, string[], "database">;
    set_selected_schemas: CommandDefinition<ConnectionIdRequest & {
        schemas: string[];
    }, void, "database">;
    get_schema_preference: CommandDefinition<ConnectionIdRequest, string | null, "database">;
    set_schema_preference: CommandDefinition<ConnectionIdRequest & {
        schema: string;
    }, void, "database">;
    get_view_definition: CommandDefinition<ViewMetadataRequest, string, "database">;
    create_view: CommandDefinition<ViewMetadataRequest & {
        definition: string;
    }, void, "database">;
    alter_view: CommandDefinition<ViewMetadataRequest & {
        definition: string;
    }, void, "database">;
    drop_view: CommandDefinition<ViewMetadataRequest, void, "database">;
    refresh_materialized_view: CommandDefinition<ViewMetadataRequest, void, "database">;
    get_routine_parameters: CommandDefinition<MetadataRequest & {
        routineName: string;
    }, RoutineParameterInfo[], "database">;
    get_routine_definition: CommandDefinition<RoutineTargetRequest, string, "database">;
    build_routine_call_sql: CommandDefinition<RoutineTargetRequest & {
        args: RoutineCallArg[];
    }, string, "database">;
    get_routine_create_template: CommandDefinition<MetadataRequest & {
        routineType: string;
    }, string, "database">;
    get_routine_edit_script: CommandDefinition<RoutineTargetRequest, string, "database">;
    drop_routine: CommandDefinition<RoutineTargetRequest, void, "database">;
    get_trigger_definition: CommandDefinition<TriggerTargetRequest, string, "database">;
    create_trigger: CommandDefinition<MetadataRequest & {
        triggerSql: string;
    }, void, "database">;
    drop_trigger: CommandDefinition<TriggerTargetRequest, void, "database">;
    get_create_table_sql: CommandDefinition<MetadataRequest & {
        tableName: string;
        columns: ColumnDefinition[];
    }, string[], "database">;
    get_add_column_sql: CommandDefinition<MetadataRequest & {
        table: string;
        column: ColumnDefinition;
    }, string[], "database">;
    get_alter_column_sql: CommandDefinition<MetadataRequest & {
        table: string;
        oldColumn: ColumnDefinition;
        newColumn: ColumnDefinition;
    }, string[], "database">;
    get_create_index_sql: CommandDefinition<MetadataRequest & {
        table: string;
        indexName: string;
        columns: string[];
        isUnique: boolean;
    }, string[], "database">;
    get_create_foreign_key_sql: CommandDefinition<MetadataRequest & {
        table: string;
        fkName: string;
        column: string;
        refTable: string;
        refColumn: string;
        onDelete?: string | null;
        onUpdate?: string | null;
    }, string[], "database">;
    drop_index_action: CommandDefinition<MetadataRequest & {
        table: string;
        indexName: string;
    }, void, "database">;
    drop_foreign_key_action: CommandDefinition<MetadataRequest & {
        table: string;
        fkName: string;
    }, void, "database">;
    get_db_privilege_catalog: CommandDefinition<ConnectionIdRequest, DbPrivilegeCatalog, "sensitive">;
    get_db_users: CommandDefinition<ConnectionIdRequest, DbUserInfo[], "sensitive">;
    get_db_user_grants: CommandDefinition<DbUserTargetRequest, string[], "sensitive">;
    get_db_user_privileges: CommandDefinition<DbUserTargetRequest, DbUserGrantSet[], "sensitive">;
    create_db_user: CommandDefinition<DbUserTargetRequest & {
        password: string;
    }, void, "sensitive">;
    drop_db_user: CommandDefinition<DbUserTargetRequest, void, "sensitive">;
    set_db_user_password: CommandDefinition<DbUserTargetRequest & {
        password: string;
    }, void, "sensitive">;
    apply_db_user_privileges: CommandDefinition<DbUserTargetRequest & {
        database: string | null;
        table: string | null;
        privileges: string[];
        grant: boolean;
    }, void, "sensitive">;
    execute_query: CommandDefinition<ExecuteQueryRequest, QueryResult, "database">;
    execute_query_batch: CommandDefinition<ExecuteQueryBatchRequest, BatchStatementResult[], "database">;
    count_query: CommandDefinition<MetadataRequest & {
        query: string;
        sessionId?: string;
    }, number, "database">;
    explain_query_plan: CommandDefinition<ExplainQueryRequest, ExplainQueryOutput, "database">;
    cancel_query: CommandDefinition<CancelQueryRequest, void, "database">;
    get_server_now: CommandDefinition<ConnectionIdRequest, string, "database">;
    get_saved_queries: CommandDefinition<ConnectionIdRequest, SavedQuery[], "database">;
    save_query: CommandDefinition<ConnectionIdRequest & {
        name: string;
        sql: string;
        database: string | null;
    }, SavedQuery, "database">;
    update_saved_query: CommandDefinition<ConnectionIdRequest & {
        id: string;
        name: string;
        sql: string;
        database: string | null;
    }, SavedQuery, "database">;
    delete_saved_query: CommandDefinition<ConnectionIdRequest & {
        id: string;
    }, void, "database">;
    get_query_history: CommandDefinition<ConnectionIdRequest, QueryHistoryResponse, "database">;
    add_query_history_entry: CommandDefinition<ConnectionIdRequest & {
        sql: string;
        executedAt: string;
        executionTimeMs: number | null;
        status: "success" | "error";
        rowsAffected: number | null;
        error: string | null;
        database: string | null;
    }, QueryHistoryEntry, "database">;
    delete_query_history_entry: CommandDefinition<ConnectionIdRequest & {
        id: string;
    }, void, "database">;
    clear_query_history: CommandDefinition<ConnectionIdRequest, void, "database">;
    create_notebook: CommandDefinition<NotebookContentRequest, void, "database">;
    save_notebook: CommandDefinition<NotebookContentRequest, void, "database">;
    load_notebook: CommandDefinition<NotebookTargetRequest, string | null, "database">;
    delete_notebook: CommandDefinition<NotebookTargetRequest, void, "database">;
    rename_notebook: CommandDefinition<NotebookTargetRequest & {
        title: string;
    }, void, "database">;
    list_notebooks: CommandDefinition<ConnectionIdRequest, NotebookMetadata[], "database">;
    delete_record: CommandDefinition<RecordIdentityRequest, number, "database">;
    update_record: CommandDefinition<RecordIdentityRequest & {
        colName: string;
        newVal: unknown;
    }, number, "database">;
    insert_record: CommandDefinition<RecordLocator & {
        data: Record<string, unknown>;
    }, number, "database">;
    fetch_blob: CommandDefinition<BlobColumnRequest, BlobFetchResponse, "database">;
    detect_blob_mime: CommandDefinition<{
        base64Data: string;
    }, string, "sensitive">;
    detect_mime_type: CommandDefinition<{
        headerBase64: string;
    }, string, "sensitive">;
    cancel_export: CommandDefinition<ConnectionIdRequest, void, "database">;
    export_query_to_file: CommandDefinition<QueryExportRequest, GeneratedFile | null, "database">;
    export_ai_activity_json: CommandDefinition<undefined, string, "sensitive">;
    export_ai_activity_csv: CommandDefinition<undefined, string, "sensitive">;
    export_ai_session_as_notebook: CommandDefinition<{
        sessionId: string;
    }, AiNotebookExport, "sensitive">;
    export_logs: CommandDefinition<{
        filePath?: string;
    }, GeneratedFile | null, "sensitive">;
    set_ai_key: CommandDefinition<{
        provider: string;
        key: string;
    }, void, "sensitive">;
    delete_ai_key: CommandDefinition<{
        provider: string;
    }, void, "sensitive">;
    check_ai_key: CommandDefinition<{
        provider: string;
    }, boolean, "sensitive">;
    check_ai_key_status: CommandDefinition<{
        provider: string;
    }, AiKeyStatus, "sensitive">;
    get_ai_models: CommandDefinition<{
        forceRefresh?: boolean;
    } | undefined, AiProviderModels, "sensitive">;
    generate_ai_query: CommandDefinition<{
        req: AiGenerateRequest;
    }, string, "sensitive">;
    explain_ai_query: CommandDefinition<{
        req: AiExplainRequest;
    }, string, "sensitive">;
    analyze_ai_explain_plan: CommandDefinition<{
        req: AiExplainRequest;
    }, string, "sensitive">;
    generate_cell_name: CommandDefinition<{
        req: AiNameRequest;
    }, string, "sensitive">;
    generate_tab_rename: CommandDefinition<{
        req: AiNameRequest;
    }, string, "sensitive">;
    suggest_table_name: CommandDefinition<{
        req: AiTableNameRequest;
    }, string, "sensitive">;
    get_ai_schema_context: CommandDefinition<{
        connectionId: string;
        schema?: string;
    }, string, "database">;
    get_ai_activity: CommandDefinition<{
        filter?: AiEventFilter;
    } | undefined, AiActivityEvent[], "sensitive">;
    get_ai_sessions: CommandDefinition<undefined, AiSessionSummary[], "sensitive">;
    get_ai_session_events: CommandDefinition<{
        sessionId: string;
    }, AiActivityEvent[], "sensitive">;
    clear_ai_activity: CommandDefinition<undefined, void, "sensitive">;
    list_pending_approvals: CommandDefinition<undefined, PendingApproval[], "sensitive">;
    decide_pending_approval: CommandDefinition<ApprovalDecisionPayload, void, "sensitive">;
    get_config: CommandDefinition<undefined, PersistedConfig, "local-admin">;
    save_config: CommandDefinition<{
        config: PersistedConfig;
    }, void, "local-admin">;
    get_config_json: CommandDefinition<undefined, string, "local-admin">;
    save_config_json: CommandDefinition<{
        json: string;
    }, void, "local-admin">;
    get_keybindings: CommandDefinition<undefined, UserOverrides, "local-admin">;
    save_keybindings: CommandDefinition<{
        keybindings: UserOverrides;
    }, void, "local-admin">;
    get_all_themes: CommandDefinition<undefined, Theme[], "local-admin">;
    save_custom_theme: CommandDefinition<{
        theme: Theme;
    }, void, "local-admin">;
    delete_custom_theme: CommandDefinition<{
        themeId: string;
    }, void, "local-admin">;
    get_system_prompt: CommandDefinition<undefined, string, "local-admin">;
    save_system_prompt: CommandDefinition<{
        prompt: string;
    }, void, "local-admin">;
    reset_system_prompt: CommandDefinition<undefined, string, "local-admin">;
    get_explain_prompt: CommandDefinition<undefined, string, "local-admin">;
    save_explain_prompt: CommandDefinition<{
        prompt: string;
    }, void, "local-admin">;
    reset_explain_prompt: CommandDefinition<undefined, string, "local-admin">;
    get_explainplan_prompt: CommandDefinition<undefined, string, "local-admin">;
    save_explainplan_prompt: CommandDefinition<{
        prompt: string;
    }, void, "local-admin">;
    reset_explainplan_prompt: CommandDefinition<undefined, string, "local-admin">;
    get_cellname_prompt: CommandDefinition<undefined, string, "local-admin">;
    save_cellname_prompt: CommandDefinition<{
        prompt: string;
    }, void, "local-admin">;
    reset_cellname_prompt: CommandDefinition<undefined, string, "local-admin">;
    get_tabrename_prompt: CommandDefinition<undefined, string, "local-admin">;
    save_tabrename_prompt: CommandDefinition<{
        prompt: string;
    }, void, "local-admin">;
    reset_tabrename_prompt: CommandDefinition<undefined, string, "local-admin">;
    load_editor_preferences: CommandDefinition<ConnectionIdRequest, EditorPreferences | null, "database">;
    save_editor_preferences: CommandDefinition<ConnectionIdRequest & {
        preferences: EditorPreferences;
    }, void, "database">;
    delete_editor_preferences: CommandDefinition<ConnectionIdRequest, void, "database">;
    get_last_active_connection: CommandDefinition<undefined, string | null, "session">;
    set_last_active_connection: CommandDefinition<{
        connectionId: string | null;
    }, void, "session">;
    get_last_open_connections: CommandDefinition<undefined, string[], "session">;
    set_last_open_connections: CommandDefinition<{
        connectionIds: string[];
    }, void, "session">;
    get_theme_catalog: CommandDefinition<undefined, NativeThemeCatalog, "session">;
    preview_theme_document: CommandDefinition<{
        source: string;
        name: string;
    }, NativeThemeContribution, "session">;
    create_personal_theme: CommandDefinition<{
        name: string;
        source: string;
    }, NativeThemeContribution, "local-admin">;
    create_personal_snapshot: CommandDefinition<{
        name: string;
        source: string;
    }, NativeThemeContribution, "local-admin">;
    update_personal_theme: CommandDefinition<{
        themeId: string;
        name: string;
        source: string;
        expectedRevision: string;
    }, NativeThemeContribution, "local-admin">;
    update_personal_snapshot: CommandDefinition<{
        themeId: string;
        name: string;
        source: string;
        editor: MonacoThemeDefinition;
        expectedRevision: string;
    }, NativeThemeContribution, "local-admin">;
    duplicate_personal_theme: CommandDefinition<{
        themeId: string;
        name: string;
        editor?: MonacoThemeDefinition | null;
    }, NativeThemeContribution, "local-admin">;
    import_theme: CommandDefinition<{
        themeJson: string;
        name?: string | null;
    }, Theme, "local-admin">;
    export_theme: CommandDefinition<{
        themeId: string;
    }, string, "local-admin">;
    preview_local_theme_package: CommandDefinition<LocalThemeArchiveRequest, LocalThemePreview, "local-admin">;
    install_local_theme_package: CommandDefinition<LocalThemeArchiveRequest & {
        packageName: string;
        expectedDigest: string;
    }, ThemeCommit, "local-admin">;
    fetch_theme_registry: CommandDefinition<{
        packageName?: string | null;
        expectedRegistryKey?: string | null;
    } | undefined, ThemeRegistrySnapshot, "local-admin">;
    fetch_theme_package_detail: CommandDefinition<{
        packageName: string;
        expectedRegistryKey: string;
        requestedRegistryUrl?: string | null;
    }, ThemeRegistryPlugin, "local-admin">;
    install_registry_theme: CommandDefinition<{
        packageName: string;
        expectedRegistryKey: string;
        version?: string | null;
    }, ThemeCommit, "local-admin">;
    cancel_theme_install: CommandDefinition<ThemePackageRequest, boolean, "local-admin">;
    set_theme_package_enabled: CommandDefinition<ThemePackageRequest & {
        enabled: boolean;
    }, void, "local-admin">;
    uninstall_theme_package: CommandDefinition<ThemePackageRequest, ThemeCommit, "local-admin">;
    recover_theme_packages: CommandDefinition<undefined, string[], "local-admin">;
    proxy_password_is_set: CommandDefinition<{
        slot: string;
    }, boolean, "sensitive">;
    set_proxy_password: CommandDefinition<{
        slot: string;
        password: string;
    }, void, "sensitive">;
    delete_proxy_password: CommandDefinition<{
        slot: string;
    }, void, "sensitive">;
    /** Paths are host paths; browsers may only use server file browser roots. */
    get_storage_location: CommandDefinition<undefined, StorageLocationInfo, "local-admin">;
    inspect_storage_location: CommandDefinition<{
        path: string;
    }, StorageLocationInspection, "local-admin">;
    set_storage_location: CommandDefinition<{
        path: string;
        copyData: boolean;
    }, StorageLocationInfo, "local-admin">;
    reset_storage_location: CommandDefinition<undefined, StorageLocationInfo, "local-admin">;
    get_app_data_dir: CommandDefinition<undefined, string, "local-admin">;
    /** Paths are host paths; browsers may only use server file browser roots. */
    read_sql_file: CommandDefinition<{
        path: string;
    }, string, "local-admin">;
    write_sql_file: CommandDefinition<{
        path: string;
        content: string;
    }, void, "local-admin">;
    get_connection_metadata: CommandDefinition<ConnectionIdRequest, ConnectionMetadata | null, "database">;
    get_plugin_runtime_warnings: CommandDefinition<undefined, PluginRuntimeWarning[], "local-admin">;
    test_ssm_connection_cmd: CommandDefinition<{
        target: string;
        profile?: string | null;
        region?: string | null;
        host: string;
        port: number;
    }, string, "local-admin">;
    /** Shared UI state (SQLite in the host config folder); omit keys to read all. */
    get_ui_state: CommandDefinition<{
        keys?: string[];
    } | undefined, UiStateEntries, "session">;
    set_ui_state: CommandDefinition<{
        key: string;
        value: unknown;
    }, void, "session">;
    delete_ui_state: CommandDefinition<{
        key: string;
    }, void, "session">;
}
type CommandName = keyof CommandMap;
type CommandRequest<K extends CommandName> = CommandMap[K]["request"];
type CommandResponse<K extends CommandName> = CommandMap[K]["response"];
interface CommandCallOptions {
    requestId?: RequestId;
    deadlineMs?: number;
    cancellationId?: string;
}
interface UnmigratedCommandTracking {
    task: `WEB-${number}`;
    callSite: `${string}:${number}`;
    reason: string;
}
interface TypedCommandCaller {
    call<K extends CommandName>(command: K, request: CommandRequest<K>, options?: CommandCallOptions): Promise<CommandResponse<K>>;
    /**
     * Temporary escape hatch for commands that are not in CommandMap yet.
     * The unknown result must be narrowed by the caller, and mandatory metadata
     * keeps every use searchable until its owning migration task removes it.
     */
    callUnmigrated<K extends string>(command: K extends CommandName ? never : K, request: unknown, tracking: UnmigratedCommandTracking, options?: CommandCallOptions): Promise<unknown>;
}

/** Payload of a "connection-test-progress" Tauri event. */
interface ConnectionTestProgressPayload {
    id: string;
    step: string;
    status: "start" | "ok" | "error";
    detail?: string | null;
}

/** Kind of prompt ssh is asking for, mirrored from the Rust askpass module. */
type SshAskpassKind = "secret" | "confirm" | "notify";
/** Payload of the `ssh-askpass://request` Tauri event. */
interface SshAskpassRequest {
    id: number;
    kind: SshAskpassKind;
    prompt: string;
}

interface EventDefinition<Payload, Authorization extends AuthorizationLevel> {
    readonly payload: Payload;
    readonly authorization: Authorization;
}
interface EventMap {
    "session-transaction-state": EventDefinition<{
        session_id: string;
        in_transaction: boolean;
    }, "database">;
    "connection-test-progress": EventDefinition<ConnectionTestProgressPayload, "database">;
    "connection-health-failed": EventDefinition<{
        connectionId: string;
        error: string;
    }, "database">;
    "connections:active-changed": EventDefinition<string[], "database">;
    "database-dropped": EventDefinition<{
        connectionId: string;
        database: string;
    }, "database">;
    "batch-statement-complete": EventDefinition<{
        batch_id: string;
        index: number;
        statement: BatchStatementResult;
    }, "database">;
    "query-status": EventDefinition<{
        requestId: RequestId;
        connectionId: string;
        status: "started" | "completed" | "failed";
    }, "database">;
    "query-cancelled": EventDefinition<{
        requestId: RequestId;
        connectionId: string;
    }, "database">;
    "dump_progress": EventDefinition<{
        connection_id: string;
        tables_processed: number;
        total_tables: number;
        percentage: number;
        current_operation: string;
    }, "database">;
    "import_progress": EventDefinition<{
        connection_id: string;
        statements_executed: number;
        total_statements: number;
        percentage: number;
        current_operation: string;
    }, "database">;
    "export_progress": EventDefinition<{
        connection_id: string;
        rows_processed: number;
    }, "database">;
    "ssh-askpass://request": EventDefinition<SshAskpassRequest, "sensitive">;
    "ssh-askpass://dismiss": EventDefinition<number, "sensitive">;
    "ai://pending_approval": EventDefinition<PendingApproval, "sensitive">;
    "ai://activity": EventDefinition<AiActivityEvent, "sensitive">;
    "theme-catalog-changed": EventDefinition<null, "session">;
    "ui-state://changed": EventDefinition<{
        key: string;
        value: unknown;
    }, "session">;
    "connection-metadata-invalidated": EventDefinition<{
        connectionId?: string;
        driverId?: string;
    }, "database">;
    "tabularis://plugin-activated": EventDefinition<{
        pluginId: string;
    }, "database">;
    "tabularis://plugin-installed": EventDefinition<{
        slug: string;
    }, "session">;
}
type EventName = keyof EventMap;
type EventPayload<K extends EventName> = EventMap[K]["payload"];
type Unsubscribe = () => void;
interface EventSubscriber {
    subscribe<K extends EventName>(event: K, handler: (payload: EventPayload<K>) => void): Promise<Unsubscribe>;
}

interface FileTransferMetadata {
    readonly token: string;
    readonly fileName: string;
    readonly mimeType: string;
    readonly size: number;
    readonly expiresAt: string;
}
interface FileUploadRequest {
    readonly contents: Blob;
    readonly fileName: string;
    /**
     * Binds the opaque token to the application workflow that may consume it.
     */
    readonly purpose: string;
}

interface TabularisTransport extends TypedCommandCaller, EventSubscriber {
    uploadFile?(request: FileUploadRequest): Promise<FileTransferMetadata>;
    consumeDownload?(token: string): Promise<Blob>;
    requestDownload?(token: string): Promise<void>;
    uploadConnectionIcon?(file: Blob): Promise<string>;
    uploadBlob?(file: Blob): Promise<string>;
    uploadedBlobUrl?(token: string): string;
    readUploadedBlob?(token: string): Promise<Blob>;
    consumeBlobDownload?(token: string): Promise<Blob>;
    readPluginAsset?(pluginId: string, assetPath: string): Promise<string>;
    emit<K extends EventName>(event: K, payload: EventPayload<K>): Promise<void>;
}
declare class TabularisClient implements TabularisTransport {
    private readonly transport;
    constructor(transport: TabularisTransport);
    call<K extends CommandName>(command: K, request: CommandRequest<K>, options?: CommandCallOptions): Promise<CommandResponse<K>>;
    callUnmigrated<K extends string>(command: K extends CommandName ? never : K, request: unknown, tracking: UnmigratedCommandTracking, options?: CommandCallOptions): Promise<unknown>;
    uploadFile(request: FileUploadRequest): Promise<FileTransferMetadata>;
    consumeDownload(token: string): Promise<Blob>;
    requestDownload(token: string): Promise<void>;
    uploadConnectionIcon(file: Blob): Promise<string>;
    uploadBlob(file: Blob): Promise<string>;
    uploadedBlobUrl(token: string): string;
    readUploadedBlob(token: string): Promise<Blob>;
    consumeBlobDownload(token: string): Promise<Blob>;
    readPluginAsset(pluginId: string, assetPath: string): Promise<string>;
    subscribe<K extends EventName>(event: K, handler: (payload: EventPayload<K>) => void): Promise<Unsubscribe>;
    emit<K extends EventName>(event: K, payload: EventPayload<K>): Promise<void>;
}

interface TabularisWorkspaceProps {
    /** Changes whenever the authorized user, database grant or session changes. */
    scopeId: string;
    connectionId: string;
    client: TabularisClient;
    locale?: "en" | "de";
    theme?: "light" | "dark";
    className?: string;
}

/** Host routing and authentication remain outside the embedded workbench. */
declare function TabularisWorkspace(props: TabularisWorkspaceProps): react_jsx_runtime.JSX.Element;

interface WebTransportCapabilities {
    readonly rpc: boolean;
    readonly events: boolean;
    readonly uploads: boolean;
    readonly downloads: boolean;
    readonly pluginAssets: boolean;
    readonly mcpHostConfiguration: boolean;
    readonly serverFileBrowser: boolean;
    readonly nativeUpdater: false;
}
interface ServerBuildInformation {
    readonly target: string;
    readonly profile: "debug" | "release";
    readonly commit: string | null;
}
interface WebQueryResponsePolicy {
    readonly maxRowsPerPage: number;
    readonly maxResponseBytes: number;
    readonly streaming: boolean;
}
type WebAuthorizationLevel = "session" | "database" | "sensitive" | "local-admin";
interface WebSessionAccessPolicy {
    readonly remote: boolean;
    readonly authorizationLevel: WebAuthorizationLevel;
    readonly highRiskCapabilities: boolean;
}
interface SessionNegotiation {
    readonly apiVersion: string;
    readonly serverVersion: string;
    readonly serverBuild: ServerBuildInformation;
    readonly authenticated: boolean;
    readonly csrfToken: string;
    readonly access: WebSessionAccessPolicy;
    readonly capabilities: WebTransportCapabilities;
    readonly queryResponsePolicy: WebQueryResponsePolicy;
}

interface WebSocketLike {
    readonly readyState: number;
    onopen: ((event: Event) => void) | null;
    onmessage: ((event: MessageEvent<unknown>) => void) | null;
    onerror: ((event: Event) => void) | null;
    onclose: ((event: CloseEvent) => void) | null;
    send(data: string): void;
    close(): void;
}
interface HttpTransportOptions {
    readonly baseUrl?: string;
    readonly fetch?: typeof fetch;
    readonly createWebSocket?: (url: string) => WebSocketLike;
    readonly reconnectDelayMs?: number;
    readonly maxReconnectDelayMs?: number;
    readonly startDownload?: (url: string) => void;
}
type EventHandler<K extends EventName> = (payload: EventPayload<K>) => void;
declare class HttpTransport implements TabularisTransport {
    private readonly baseUrl;
    private readonly fetchRequest;
    private readonly createSocket;
    private readonly reconnectDelayMs;
    private readonly maxReconnectDelayMs;
    private readonly startBrowserDownload;
    private readonly handlers;
    private session?;
    private sessionPromise?;
    private socket;
    private connectionPromise;
    private reconnectTimer;
    private reconnectAttempt;
    private lastSequence;
    private intentionalClose;
    constructor(options?: HttpTransportOptions);
    initialize(): Promise<SessionNegotiation>;
    call<K extends CommandName>(command: K, request: CommandRequest<K>, options?: CommandCallOptions): Promise<CommandResponse<K>>;
    callUnmigrated<K extends string>(command: K extends CommandName ? never : K, request: unknown, _tracking: UnmigratedCommandTracking, options?: CommandCallOptions): Promise<unknown>;
    uploadFile(request: FileUploadRequest): Promise<FileTransferMetadata>;
    consumeDownload(token: string): Promise<Blob>;
    requestDownload(token: string): Promise<void>;
    readPluginAsset(pluginId: string, assetPath: string): Promise<string>;
    uploadConnectionIcon(file: Blob): Promise<string>;
    uploadBlob(file: Blob): Promise<string>;
    uploadedBlobUrl(token: string): string;
    readUploadedBlob(token: string): Promise<Blob>;
    consumeBlobDownload(token: string): Promise<Blob>;
    subscribe<K extends EventName>(event: K, handler: EventHandler<K>): Promise<Unsubscribe>;
    emit<K extends EventName>(_event: K, _payload: EventPayload<K>): Promise<void>;
    private loadSession;
    private callRpc;
    private ensureConnected;
    private subscribeAll;
    private removeSubscription;
    private handleSocketMessage;
    private deliverEvent;
    private isSubscribedEvent;
    private eventHandlers;
    private subscribedEvents;
    private sendControl;
    private scheduleReconnect;
    private clearReconnectTimer;
    private websocketUrl;
    private url;
}

export { type CommandCallOptions, type CommandName, type CommandRequest, type CommandResponse, HttpTransport, type HttpTransportOptions, type SessionNegotiation, TabularisClient, type TabularisTransport, TabularisWorkspace, type TabularisWorkspaceProps };

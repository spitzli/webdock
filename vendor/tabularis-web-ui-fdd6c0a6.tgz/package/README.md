# @tabularis/web-ui

The existing Tabularis explorer, SQL editor and result grid, embedded in a React host. This branch builds on Tabularis Web PR #676; it is not a published release.

```tsx
import { TabularisWorkspace, TabularisClient, HttpTransport } from '@tabularis/web-ui';
import '@tabularis/web-ui/workspace.css';

const transport = new HttpTransport({ baseUrl: 'https://database.example/s/123' });
const client = new TabularisClient(transport);

<TabularisWorkspace client={client} scopeId="authorization-session-123"
  connectionId="123" locale="en" theme="light" />;
```

Mount in a container with an explicit height. Load this browser-only component lazily with SSR disabled in Next.js. The library externalizes React/React DOM. Its stylesheet uses CSS `@scope`, requiring a browser with support for that feature.

Keep `client` stable across appearance updates. Change `scopeId` whenever the authorized session, database or grant changes. Internal routing does not change the host URL. Workspace preferences and appearance are isolated from document styling and the standalone browser cache. Host navigation and plugin extension loading are omitted. The current embedded locale choices are English and German.

The host owns authentication, transport disposal and backend authorization. UI visibility is not a security boundary. A gateway must constrain every command to authorized connections, prevent arbitrary connection configuration and enforce database privileges with actual database roles. The desktop `database` authorization tier includes writes and is not tenant isolation. Saved queries and editor state require the same backend scope as database execution.

Build an installable local artifact with `pnpm --filter @tabularis/web-ui build:library`, then `pnpm --filter @tabularis/web-ui pack`. Both normal `pnpm build` and desktop entry points remain available.
